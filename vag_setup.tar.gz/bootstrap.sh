#!/usr/bin/env bash

sudo apt-get update
sudo apt-get install make
#Gets and installs Apache Web Server
sudo apt-get install -y apache2
rm -rf /var/www
ln -fs /vagrant /var/www

sudo su -
cd /home/vagrant
#Imports Python 2.6.8 from shared folder (/var/www) and installs it
wget http://localhost/Python-2.6.8.tar.gz
tar xzvf Python-2.6.8.tar.gz
cd Python-2.6.8
./configure
make install
cd ..
#Imports SQLite 3.5.9 from shared folder (/var/www) and installs it
wget http://localhost/sqlite-3.5.9.tar.gz
tar xzf sqlite-3.5.9.tar.gz
mkdir bld
cd bld
../sqlite-3.5.9/configure
make
make install
cd ..
#Imports Django 1.6 form shared folder (/var/www) and installs it
wget http://localhost/Django-1.6.tar.gz
tar xzvf Django-1.6.tar.gz
cd Django-1.6
python setup.py install
